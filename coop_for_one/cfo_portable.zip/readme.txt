Start the game by starting the executeable in the bin folder.
If you get "MSVCP140.dll is missing", please install Visual C++ Redistributable for Visual Studio 2015.
To do this start the executeable in the "additionalSetup" folder.
When the graphics aren't displayed correctly please update your graphic card driver.
Controls:
Menu: w/s ; arrow up/down; enter/space to select
Green Characer - wasd
Red Character - arrow keys
Back to Main Menu - Esc 
